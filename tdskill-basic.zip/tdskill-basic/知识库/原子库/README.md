# 原子库说明

## 数据来源

- 公众号推文总数：167 篇
- 最终知识原子：148 条
- 时间范围：2023-09 ~ 2026-07

## 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| id | string | 格式：{季度}_{序号}，如 2023Q3_001 |
| knowledge | string | 提炼后的知识点陈述句 |
| original | string | 推文原文（最多200字） |
| date | string | 发布日期 |
| topics | string[] | 主题分类 |
| skills | string[] | 关联 Skill |
| type | string | principle/method/case/anti-pattern/insight/tool |
| confidence | string | high/medium/low |

## 文件结构

- `atoms.jsonl` — 全量合并（148 条）
- `atoms_{季度}.jsonl` — 按季度拆分
